
import os, base64, httpx
from google.cloud import vision

class ReverseImageSearchAdapter:
    def __init__(self):
        self.serp_key = os.environ.get("SERPAPI_KEY")
        if not self.serp_key:
            raise RuntimeError("SERPAPI_KEY is required")
        self.vision_client = vision.ImageAnnotatorClient()

    async def search(self, image_bytes: bytes) -> dict:
        lens_payload = {
            "engine": "google_lens",
            "api_key": self.serp_key,
            "hl": "ja",
            "image_content": base64.b64encode(image_bytes).decode("utf-8"),
        }
        async with httpx.AsyncClient(timeout=60) as client:
            r = await client.post("https://serpapi.com/search.json", data=lens_payload)
            r.raise_for_status()
            lens = r.json()

        sim_items, pages = [], []

        for it in (lens.get("visual_matches") or []):
            sim_items.append({
                "url": it.get("link") or "",
                "thumbnail": (it.get("thumbnail") or it.get("image")) or "",
                "score": 0.0,
            })
        for it in (lens.get("pages") or []):
            if it.get("link"):
                pages.append({"url": it["link"]})

        img = vision.Image(content=image_bytes)
        wd = self.vision_client.web_detection(image=img).web_detection
        if wd:
            for p in (wd.pages_with_matching_images or []):
                if p.url:
                    pages.append({"url": p.url})
            for vi in (wd.visually_similar_images or []):
                sim_items.append({"url": vi.url, "thumbnail": vi.url, "score": 0.0})

        # dedupe
        seen = set(); uniq_sim = []
        for x in sim_items:
            u = x.get("url")
            if u and u not in seen:
                seen.add(u); uniq_sim.append(x)
        seen = set(); uniq_pages = []
        for x in pages:
            u = x.get("url")
            if u and u not in seen:
                seen.add(u); uniq_pages.append(x)

        return {"similar_images": uniq_sim[:50], "pages": uniq_pages[:50]}
