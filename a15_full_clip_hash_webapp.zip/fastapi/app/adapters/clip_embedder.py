
import io, torch, numpy as np
from PIL import Image
import open_clip

class ClipEmbedder:
    def __init__(self, model_name: str = "ViT-B-32", pretrained: str = "openai", device: str = "cpu"):
        self.device = device
        self.model, _, self.preprocess = open_clip.create_model_and_transforms(
            model_name, pretrained=pretrained, device=self.device
        )
        self.model.eval()

    def embed_image(self, image_bytes: bytes) -> list[float]:
        img = Image.open(io.BytesIO(image_bytes)).convert("RGB")
        with torch.no_grad():
            image = self.preprocess(img).unsqueeze(0).to(self.device)
            feats = self.model.encode_image(image)
            feats = feats / feats.norm(dim=-1, keepdim=True)
        vec = feats.squeeze(0).cpu().numpy().astype("float32")
        return vec.tolist()
