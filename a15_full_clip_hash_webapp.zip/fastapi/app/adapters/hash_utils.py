
from PIL import Image
import imagehash
import io

def compute_hashes(image_bytes: bytes) -> dict:
    img = Image.open(io.BytesIO(image_bytes)).convert("RGB")
    return {
        "ahash": str(imagehash.average_hash(img)),
        "phash": str(imagehash.phash(img)),
        "dhash": str(imagehash.dhash(img)),
        "whash": str(imagehash.whash(img)),
    }
