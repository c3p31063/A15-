
from fastapi import FastAPI, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from .adapters.web_search import ReverseImageSearchAdapter
from .adapters.hash_utils import compute_hashes
from .adapters.clip_embedder import ClipEmbedder

app = FastAPI(title="A15 Risk Engine")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://127.0.0.1:8000", "http://localhost:8000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

clip = ClipEmbedder()

@app.get("/")
def root():
    return {"ok": True, "docs": "/docs", "endpoints": ["/check/image"]}

@app.post("/check/image")
async def check_image(file: UploadFile = File(...), prompt: str | None = Form(None)):
    image_bytes = await file.read()
    ris = ReverseImageSearchAdapter()
    out = await ris.search(image_bytes)

    hashes = compute_hashes(image_bytes)
    clip_vec = clip.embed_image(image_bytes)

    result = {
        "risk_level": "manual_review",
        "risk_score_total": 0.0,
        "threshold_version": "v1",
        "evidences": [{"url": p["url"], "source": "web"} for p in out.get("pages", [])],
        "similar_images": [{"url": s["url"], "thumbnail": s.get("thumbnail",""), "score": s.get("score", 0.0)} for s in out.get("similar_images", [])],
        "hashes": hashes,
        "clip_vector": clip_vec,
        "clip_model": "open_clip/ViT-B-32@openai",
        "raw": out,
    }
    return result
