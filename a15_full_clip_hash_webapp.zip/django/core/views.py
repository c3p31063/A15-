
import os, uuid, requests
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.utils import timezone
from django.conf import settings
from .forms import UploadForm
from .services.firestore_repo import (
    save_job_meta, save_similar_images, save_evidences, save_vectors_and_hashes,
    load_job, load_result, write_audit,
)

FASTAPI_URL = getattr(settings, "FASTAPI_URL", "http://127.0.0.1:8001")

@login_required
def dashboard_view(request):
    return render(request, "core/dashboard.html", {})

@login_required
def upload_view(request):
    if request.method == "POST":
        form = UploadForm(request.POST, request.FILES)
        if form.is_valid():
            kind = form.cleaned_data["kind"]
            prompt = form.cleaned_data.get("prompt") or ""
            user = request.user

            job_id = uuid.uuid4().hex
            save_job_meta(job_id, user.id, {
                "kind": kind, "status": "running",
                "created_at": timezone.now(),
            })
            write_audit(user.id, "upload", job_id, request.META.get("REMOTE_ADDR"), request.META.get("HTTP_USER_AGENT"))

            try:
                if kind == "image" and request.FILES.get("image"):
                    f = request.FILES["image"]
                    files = {"file": (f.name, f.read(), f.content_type or "application/octet-stream")}
                    data = {"prompt": prompt}
                    r = requests.post(f"{FASTAPI_URL}/check/image", files=files, data=data, timeout=180)
                    r.raise_for_status()
                    res = r.json()
                else:
                    res = {
                        "risk_level": "manual_review",
                        "risk_score_total": 0.0,
                        "threshold_version": "v1",
                        "evidences": [],
                        "similar_images": [],
                        "hashes": None,
                        "clip_vector": None,
                    }

                save_job_meta(job_id, user.id, {
                    "status": "done",
                    "finished_at": timezone.now(),
                    "threshold_version": res.get("threshold_version", "v1"),
                    "risk_level": res.get("risk_level", "manual_review"),
                    "risk_score_total": res.get("risk_score_total", 0.0),
                })
                save_evidences(job_id, res.get("evidences", []))
                save_similar_images(job_id, res.get("similar_images", []))
                save_vectors_and_hashes(job_id, res.get("clip_vector"), res.get("hashes"))

                return redirect("job_detail", job_id=job_id)
            except Exception as e:
                save_job_meta(job_id, user.id, {
                    "status": "error",
                    "finished_at": timezone.now(),
                    "error": str(e),
                })
                return render(request, "core/upload.html", {"form": form, "error": str(e)})
    else:
        form = UploadForm()
    return render(request, "core/upload.html", {"form": form})

@login_required
def job_detail_view(request, job_id: str):
    meta = load_job(job_id)
    evidences, simimgs = load_result(job_id)
    write_audit(request.user.id, "view_job", job_id, request.META.get("REMOTE_ADDR"), request.META.get("HTTP_USER_AGENT"))

    class JobObj: pass
    job = JobObj()
    for k, v in meta.items():
        setattr(job, k, v)
    job.id = job_id

    return render(request, "core/job_detail.html", {
        "job": job,
        "evidences": evidences,
        "simimgs": simimgs,
    })
