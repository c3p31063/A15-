
import os
from google.cloud import firestore

_prefix = os.environ.get("FIRESTORE_COLLECTION_PREFIX", "a15")
_db = firestore.Client()

def _col(name):
    return _db.collection(f"{_prefix}_{name}")

def save_job_meta(job_id: str, user_id: int, meta: dict):
    _col("jobs").document(str(job_id)).set({
        "user_id": str(user_id),
        **meta
    }, merge=True)

def save_similar_images(job_id: str, items: list[dict]):
    ref = _col("jobs").document(str(job_id)).collection("similar_images")
    for i, x in enumerate(items, 1):
        ref.document(str(i)).set({
            "rank": i,
            "match_url": x.get("url", ""),
            "thumbnail_url": x.get("thumbnail", ""),
            "match_score": float(x.get("score") or 0.0),
        })

def save_evidences(job_id: str, items: list[dict]):
    ref = _col("jobs").document(str(job_id)).collection("evidences")
    for i, x in enumerate(items, 1):
        ref.document(str(i)).set({
            "rank": i,
            "url": x.get("url", ""),
            "source": x.get("source"),
            "score_numeric": x.get("score_numeric"),
        })

def save_vectors_and_hashes(job_id: str, clip_vector: list[float] | None, hashes: dict | None):
    doc = {}
    if clip_vector:
        doc["clip_vector"] = clip_vector
        doc["clip_dim"] = len(clip_vector)
    if hashes:
        doc["hashes"] = hashes
    if doc:
        _col("jobs").document(str(job_id)).set(doc, merge=True)

def load_job(job_id: str) -> dict:
    doc = _col("jobs").document(str(job_id)).get()
    return doc.to_dict() or {}

def load_result(job_id: str):
    sims = [d.to_dict() for d in _col("jobs").document(str(job_id)).collection("similar_images").stream()]
    evs  = [d.to_dict() for d in _col("jobs").document(str(job_id)).collection("evidences").stream()]
    sims.sort(key=lambda x: x.get("rank", 10**9))
    evs.sort(key=lambda x: x.get("rank", 10**9))
    return evs, sims

def write_audit(user_id: int, action: str, job_id: str|None=None, ip: str|None=None, ua: str|None=None):
    _col("audit_logs").add({
        "user_id": str(user_id),
        "action": action,
        "job_id": str(job_id) if job_id else None,
        "ip": ip,
        "user_agent": ua,
        "at": firestore.SERVER_TIMESTAMP,
    })
