
from django import forms

class UploadForm(forms.Form):
    kind = forms.ChoiceField(choices=(("image","image"),("text","text")), initial="image")
    image = forms.ImageField(required=False)
    prompt = forms.CharField(required=False, widget=forms.Textarea(attrs={"rows":3}))
