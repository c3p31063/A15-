
A15 WebApp (Django + FastAPI + Firestore + Vision + SerpAPI + CLIP + ImageHash)

1) Put your GCP service account at keys/gcp-service-account.json
2) FastAPI:
   cd fastapi
   python -m venv .venv && .venv\Scripts\activate
   pip install -r requirements.txt
   pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cpu
   set SERPAPI_KEY=...
   set GOOGLE_APPLICATION_CREDENTIALS=..\keys\gcp-service-account.json
   python -m uvicorn app.main:app --reload --port 8001

3) Django:
   cd django
   python -m venv .venv && .venv\Scripts\activate
   pip install -r requirements.txt
   set FASTAPI_URL=http://127.0.0.1:8001
   set GOOGLE_APPLICATION_CREDENTIALS=..\keys\gcp-service-account.json
   set FIRESTORE_COLLECTION_PREFIX=a15
   python manage.py migrate
   python manage.py createsuperuser
   python manage.py runserver 127.0.0.1:8000

Login at /accounts/login/, then /upload to test.
